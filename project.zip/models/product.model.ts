export interface Product {
  rollo: string;
  calibre: string;
  ral: string;
  color: string;
  pesoKg: number;
  importador: string;
  observaciones: string;
  fechaIngreso: Date;
  estado: string;
};
