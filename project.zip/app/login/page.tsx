import Login from "@/components/Login";
import React from "react";

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
